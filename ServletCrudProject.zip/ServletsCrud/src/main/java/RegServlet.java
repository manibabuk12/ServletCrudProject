

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/RegServlet")
public class RegServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		String name = request.getParameter("name");
		String password=request.getParameter("password");  
	    String email=request.getParameter("email");  
	    String country=request.getParameter("country");
	    
	    Data d = new Data();
	    d.setName(name);
	    d.setPassword(password);
	    d.setEmail(email);
	    d.setCountry(country);
	    
	  int status =  Service.save(d);
	  
	  PrintWriter out = response.getWriter();
	  out.println(status);
		
	}

	
}
