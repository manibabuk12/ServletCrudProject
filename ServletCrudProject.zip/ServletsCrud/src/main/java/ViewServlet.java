

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/ViewServlet")
public class ViewServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		List<Data> list= Service.fetch();
		
		
		PrintWriter out = response.getWriter();
		
		response.setContentType("text/html");
		
		out.println("<h1>List</h1>");
		
		out.println("<table border='1' width='100'");
		
		out.println("<tr><th>name</th><th>Email</th><th>Password</th><th>Country</th></tr>");
		
		for(Data d:list)
		{
			out.println("<tr><td>"+d.getName()+"</td><td>"+d.getEmail()+"</td><td>"+d.getPassword()+"</td><td>"+d.getCountry()+"<t/d></tr>");
		}
		out.println("</table>");
		out.println("<a href='Resistration.html'>Resistration</a>");
		out.println("<a href='Delete.html'>Delete</a>");
		out.println("<a href='Update.html'>Update</a>");
		
	}
}
