

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/UpdateCtrl")
public class UpdateCtrl extends HttpServlet {
	
	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		PrintWriter out = response.getWriter();
		
		String name = request.getParameter("name");
		String email = request.getParameter("email");
		String password = request.getParameter("password");
		String country = request.getParameter("country");
		
		out.print(name);
		out.print(email);
		
		Data d = new Data();
		d.setName(name);
		d.setEmail(email);
		
		
		int status = Service.update(d);
		
//		if(status > 0)
//		{
//			response.sendRedirect("ViewServlet");
//		}
//		else
//		{
//			out.println("sorry unable to change");
//		}
		
	}

}
