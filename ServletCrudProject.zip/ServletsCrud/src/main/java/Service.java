import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

public class Service {
	
	
public static int save(Data d)
{
	int status = 0;
	
	try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
	PreparedStatement ps = con.prepareStatement("insert into cru values(?,?,?,?)");
	ps.setString(1, d.getName());
	ps.setString(2, d.getEmail());
	ps.setString(3, d.getPassword());
	ps.setString(4, d.getCountry());
	
	status = ps.executeUpdate();
	}
	catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	return status;
}

public static List<Data> fetch()
{
	List<Data> list = new ArrayList<Data>();
	try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
	PreparedStatement ps = con.prepareStatement("select * from cru");
	ResultSet rs = ps.executeQuery();
	
	while(rs.next())
	{
		Data d = new Data();
		d.setName(rs.getString(1));
		d.setEmail(rs.getString(2));
		d.setPassword(rs.getString(3));
		d.setCountry(rs.getString(4));
		
		list.add(d);
	}
	}
	catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	return list;	
	
	
	
}

public static int update(Data d)
{
	int status = 0;
	try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
	PreparedStatement ps = con.prepareStatement("update cru set name=? where email=?");
	
	ps.setString(1,d.getName());
	ps.setString(2,d.getEmail());
	
	
	status = ps.executeUpdate();
	con.close();
	
	
	}
	catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	return status;
}

public static int delete(String email)
{
	int status = 0;
	try {
	Class.forName("oracle.jdbc.driver.OracleDriver");
	Connection con = DriverManager.getConnection("jdbc:oracle:thin:@localhost:1521:xe","system","1234");
	PreparedStatement ps = con.prepareStatement("delete from cru where email=?");
	
	ps.setString(1,email);
	ps.executeUpdate();
	}
	catch (Exception e) {
		e.printStackTrace();
		// TODO: handle exception
	}
	return status;
}

}
